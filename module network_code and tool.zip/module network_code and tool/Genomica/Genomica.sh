$JAVA_HOME/bin/java -mx2048m -jar Genomica.jar &
